ALHAJGORDEN13 — WEBSITE DENGAN PANEL EDITOR

Setelah dipasang ke GitHub + Netlify, buka:
https://NAMA-SITE.netlify.app/admin/

Di panel admin Anda bisa:
- Tambah/hapus produk
- Ubah nama, harga, deskripsi
- Upload banyak foto produk
- Ubah link Shopee/TikTok/WhatsApp
- Pilih produk unggulan
- Ubah nama toko dan teks halaman utama

PENTING: Agar perubahan dari /admin/ otomatis masuk ke website publik, proyek harus tersimpan di GitHub/GitLab dan Netlify terhubung ke repository tersebut. Decap CMS menggunakan Git Gateway/Netlify authentication untuk alur ini.
