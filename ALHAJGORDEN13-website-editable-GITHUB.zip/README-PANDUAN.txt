ALHAJGORDEN13 — WEBSITE EDITABLE MELALUI GITHUB

File utama:
- index.html
- content/settings.json
- content/products.json

Edit settings.json untuk nama toko, judul, deskripsi, WhatsApp, Shopee, TikTok, dan foto utama.
Edit products.json untuk menambah/mengubah produk. Setelah Commit changes, Netlify akan otomatis deploy dari GitHub.

Foto Semokring bawaan sudah tertanam di index.html, jadi folder images tidak wajib diupload. Untuk produk baru, field images dapat berisi URL gambar langsung atau path gambar yang ada di repo.
